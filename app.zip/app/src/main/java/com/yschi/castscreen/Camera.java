package com.yschi.castscreen;

import android.os.Bundle;

/**
 * Created by Dell on 07-08-2017.
 */

public class Camera extends iqute {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_camera);
    }
}

